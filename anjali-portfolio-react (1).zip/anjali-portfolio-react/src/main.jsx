import React from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight, Github, Linkedin, Mail, MapPin, Code2, Braces,
  Database, Globe, Layers3, BriefcaseBusiness, GraduationCap,
  Trophy, ExternalLink, Menu, Sparkles, Download
} from "lucide-react";
import "./styles.css";

const skills = [
  { title: "Frontend", items: ["HTML", "CSS", "JavaScript", "React.js"], icon: Globe },
  { title: "Backend", items: ["Node.js", "Express.js", "REST APIs"], icon: Braces },
  { title: "Database", items: ["MongoDB"], icon: Database },
  { title: "Tools & workflow", items: ["Git", "GitHub", "Responsive design"], icon: Layers3 },
];

const projects = [
  {
    number: "01",
    title: "Clinic Management System",
    category: "FULL-STACK PROJECT",
    description: "A clinic workflow application focused on organizing day-to-day operations and making key information easier to manage.",
    features: ["Patient records", "Appointment booking", "Billing module", "Pharmacy assistant module"],
    stack: ["React", "Node.js", "Express.js", "MongoDB"],
    note: "Replace or refine this summary to match the exact features implemented in your project.",
  },
];

const experience = [
  {
    role: "Full-Stack Developer Intern",
    company: "Faith Info Tech",
    detail: "Practical experience in a full-stack development environment.",
    note: "Add your internship dates and specific responsibilities from your resume.",
  },
];

const achievements = [
  {
    title: "NASA International Space Apps Challenge",
    detail: "Recognition noted in resume. Add the exact award or project title if applicable.",
    icon: Sparkles,
  },
  {
    title: "NEUROBOTS National Level Hackathon",
    detail: "Participation noted in resume. Add year, project name, and result if you want them displayed.",
    icon: Trophy,
  },
];

function SectionHeading({ eyebrow, title, text }) {
  return (
    <div className="section-heading">
      <span className="eyebrow">{eyebrow}</span>
      <h2>{title}<span className="accent">.</span></h2>
      {text && <p>{text}</p>}
    </div>
  );
}

function App() {
  return (
    <div className="site-shell">
      <header className="nav-wrap">
        <a className="brand" href="#home" aria-label="Back to top"><span className="brand-mark">A</span><span>PORTFOLIO<span className="accent">.</span></span></a>
        <nav className="nav-links">
          <a href="#about">About</a><a href="#skills">Skills</a><a href="#projects">Projects</a><a href="#experience">Experience</a><a href="#contact" className="nav-contact">Contact <ArrowUpRight size={15}/></a>
        </nav>
      </header>

      <main>
        <section className="hero section-width" id="home">
          <div className="hero-copy">
            <div className="status-pill"><span className="status-dot" /> OPEN TO LEARNING & OPPORTUNITIES</div>
            <p className="hero-kicker">HELLO, I'M</p>
            <h1>An aspiring<br/><span className="gradient-text">Full-Stack</span><br/>Developer<span className="accent">.</span></h1>
            <p className="hero-intro">MCA student passionate about building useful web experiences, learning modern technologies, and turning ideas into practical projects.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#projects">Explore my work <ArrowUpRight size={17}/></a>
              <a className="button button-secondary" href="#contact">Get in touch <Mail size={16}/></a>
            </div>
            <div className="hero-socials">
              <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub profile"><Github size={18}/></a>
              <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn profile"><Linkedin size={18}/></a>
              <span className="social-note">Connect with me</span>
            </div>
          </div>
          <div className="hero-art profile-art" aria-label="Profile photo and developer introduction">
            <div className="profile-glow"/>
            <div className="profile-photo-frame">
              <img className="profile-photo" src="/profile-photo.jpeg" alt="Anjali smiling outdoors" />
              <span className="profile-photo-ring"/>
            </div>
            <div className="profile-badge"><span className="status-dot"/><span><b>Always learning</b><small>Building one step at a time</small></span></div>
            <div className="profile-caption"><Code2 size={15}/><span>Developer in progress</span></div>
          </div>
          <a className="scroll-cue" href="#about"><span/> SCROLL TO EXPLORE</a>
        </section>

        <section className="about section-width section-pad" id="about">
          <SectionHeading eyebrow="A LITTLE ABOUT ME" title="Curious by nature. Builder by practice" text="I enjoy exploring how websites and applications work, connecting frontend experiences with backend logic, and improving my skills through hands-on development."/>
          <div className="about-grid">
            <div className="about-card about-main-card"><span className="card-index">01 / PROFILE</span><h3>Learning today.<br/><span className="accent">Building for tomorrow.</span></h3><p>My goal is to grow as a developer by creating clean, useful applications and learning from real-world challenges.</p><div className="location-line"><MapPin size={16}/> <span>India</span><span className="dot-separator"/> <GraduationCap size={17}/> <span>MCA Student</span></div></div>
            <div className="about-card mini-card"><span className="mini-icon"><Code2 size={20}/></span><h3>Problem solving</h3><p>Break challenges into manageable steps and learn by doing.</p></div>
            <div className="about-card mini-card"><span className="mini-icon purple"><Layers3 size={20}/></span><h3>Full-stack mindset</h3><p>Interested in how the UI, server, and database work together.</p></div>
          </div>
        </section>

        <section className="skills section-width section-pad" id="skills">
          <SectionHeading eyebrow="MY TOOLKIT" title="Skills & technologies" text="A snapshot of the technologies listed in my development toolkit. This section can grow as I gain more hands-on experience."/>
          <div className="skill-grid">{skills.map(({title, items, icon: Icon}) => <article className="skill-card" key={title}><div className="skill-card-top"><span className="skill-icon"><Icon size={20}/></span><span className="skill-arrow"><ArrowUpRight size={16}/></span></div><h3>{title}</h3><div className="tag-list">{items.map(item => <span className="tag" key={item}>{item}</span>)}</div></article>)}</div>
        </section>

        <section className="projects section-width section-pad" id="projects">
          <SectionHeading eyebrow="SELECTED WORK" title="Projects that put skills into practice" text="A project is more than a title—it's a chance to show how you think, plan, and build."/>
          {projects.map(project => <article className="project-card" key={project.number}>
            <div className="project-visual"><div className="project-browser"><div className="browser-bar"><i/><i/><i/><span>clinic-management / dashboard</span></div><div className="mock-dashboard"><aside><b>CM</b><span/><span/><span/><span/></aside><div className="mock-content"><div className="mock-heading"><span/><span/></div><div className="mock-stats"><i/><i/><i/></div><div className="mock-table"><b/><b/><b/><b/></div><div className="mock-lower"><i/><i/></div></div></div></div><span className="visual-label">PROJECT / {project.number}</span></div>
            <div className="project-info"><span className="eyebrow">{project.category}</span><h3>{project.title}</h3><p>{project.description}</p><h4>KEY MODULES</h4><ul className="feature-list">{project.features.map(f => <li key={f}>{f}</li>)}</ul><h4>TECH STACK</h4><div className="tag-list">{project.stack.map(s => <span className="tag" key={s}>{s}</span>)}</div><p className="editable-note">{project.note}</p><a className="text-link" href="#contact">Ask me about this project <ArrowUpRight size={16}/></a></div>
          </article>)}
        </section>

        <section className="experience section-width section-pad" id="experience">
          <SectionHeading eyebrow="MY JOURNEY" title="Experience & education" text="The foundation behind my learning journey and interest in software development."/>
          <div className="timeline">
            <div className="timeline-item"><span className="timeline-marker"><BriefcaseBusiness size={17}/></span><div className="timeline-content"><span className="eyebrow">INTERNSHIP</span><h3>{experience[0].role}</h3><h4>{experience[0].company}</h4><p>May 4, 2026 – May 11, 2026 · Thiruvananthapuram, Kerala</p><p>Worked on a Clinic Management System, including patient records, appointments, billing, and a pharmacy assistant module for medicine inventory and prescription management.</p></div></div>
            <div className="timeline-item"><span className="timeline-marker"><GraduationCap size={18}/></span><div className="timeline-content"><span className="eyebrow">EDUCATION</span><h3>Master of Computer Applications (MCA)</h3><h4>Mar Athanasius College for Advanced Studies · Thiruvalla, Kerala</h4><p>Expected completion: May 2027</p><div className="timeline-divider"/><h3>Bachelor of Computer Applications (BCA)</h3><h4>Sas SNDP Yogam College · Konni, Kerala</h4><p>May 2025</p></div></div>
          </div>
        </section>

        <section className="achievements section-width section-pad" id="achievements">
          <SectionHeading eyebrow="MILESTONES" title="Achievements & activities" text="Experiences that reflect curiosity, teamwork, and a willingness to take on technical challenges."/>
          <div className="achievement-grid">{achievements.map(({title, detail, icon: Icon}) => <article className="achievement-card" key={title}><span className="achievement-icon"><Icon size={21}/></span><h3>{title}</h3><p>{detail}</p></article>)}</div>
          <div className="cert-note"><Trophy size={18}/><p><b>Certifications:</b> Add certification names, issuing organizations, and dates here to match the details in your resume.</p></div>
        </section>

        <section className="contact section-width section-pad" id="contact">
          <div className="contact-card"><div className="contact-glow"/><span className="eyebrow">LET'S CONNECT</span><h2>Have an opportunity<br/>or a project in mind<span className="accent">?</span></h2><p>I’m happy to connect, learn from others, and discuss development opportunities.</p><div className="contact-actions"><a className="button button-primary" href="mailto:your.email@example.com">Email me <Mail size={17}/></a><a className="button button-secondary" href="https://www.linkedin.com/" target="_blank" rel="noreferrer">LinkedIn <Linkedin size={16}/></a></div><p className="editable-note contact-edit-note">Replace the placeholder email and social links with your actual contact details before publishing.</p></div>
        </section>
      </main>

      <footer className="footer section-width"><a className="brand" href="#home"><span className="brand-mark">A</span><span>PORTFOLIO<span className="accent">.</span></span></a><p>Designed with curiosity · Built with React</p><a href="#home" className="back-top">Back to top ↑</a></footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
