# Personal Portfolio — React + Vite

A responsive, modern-dark portfolio starter with teal accents.

## Run locally

1. Install Node.js (LTS).
2. Extract this folder and open a terminal in it.
3. Run:

```bash
npm install
npm run dev
```

4. Open the local URL shown by Vite.

To create a production build:

```bash
npm run build
```

## Personalize before publishing

Search the project for `Replace`, `Add`, `your.email@example.com`, `Anjali`, and the placeholder social links.

Update:
- Name and headline
- GitHub and LinkedIn profile URLs
- Contact email
- Education institution, dates, and previous degree
- Internship dates and responsibilities
- Project details and actual tech stack
- Exact achievements, certification names, issuers, and dates

Education and internship details visible in the resume have been added. Confirm the project module descriptions and technology stack against your actual implementation, and fill in contact and social profile links before publishing.

## Deploy

You can deploy the Vite project to services such as Vercel or Netlify after updating the personal details and confirming the build succeeds.
